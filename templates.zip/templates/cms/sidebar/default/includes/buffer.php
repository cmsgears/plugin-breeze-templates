<?php if( $widget->buffer ) { ?>
	<div class="sidebar-widget-buffer">
		<?= $widget->bufferData ?>
	</div>
<?php } ?>

<?php include "$defaultIncludes/attributes.php"; ?>
<?php include "$defaultIncludes/widgets.php"; ?>
