<?php
$sidebarType = !empty( $settings->sidebarType ) ? $settings->sidebarType : null;
?>
