<?php if( $widget->buffer ) { ?>
	<div class="block-content-buffer">
		<?= $widget->bufferData ?>
	</div>
<?php } ?>

<!-- <div class="block-content-buffer"></div> -->

<?php include "$templateIncludes/slider.php"; ?>

<?php include "$defaultIncludes/attributes.php"; ?>
