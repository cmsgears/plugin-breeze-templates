<?php if( $widget->buffer ) { ?>
	<div class="block-widget-buffer">
		<?= $widget->bufferData ?>
	</div>
<?php } ?>

<!-- <div class="block-content-buffer"></div> -->

<?php include "$templateIncludes/attributes.php"; ?>
