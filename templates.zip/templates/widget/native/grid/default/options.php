<?php
$title	= $widget->title;
?>
<div class="grid-options-wrap row">
	<div class="colf colf12x6">
		<?= $bulkHtml ?>
		<?= $sortHtml ?>
		<?= $filtersHtml ?>
	</div>
	<div class="colf colf12x6 align align-right">
		<?= $searchHtml ?>
	</div>
</div>
