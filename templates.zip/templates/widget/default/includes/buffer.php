<?php if( $widget->buffer ) { ?>
	<div class="widget-buffer">
		<?= $widget->bufferData ?>
	</div>
<?php } ?>

<!-- <div class="widget-content-buffer"></div> -->

<?php include "$defaultIncludes/attributes.php"; ?>
