<div class="spinner max-area-cover bkg-transparent bkg-transparent-black">
	<div class="wrap-spinner valign-center">
		<i class="cmti cmti-2x cmti-spinner-10 spin text text-white"></i>
	</div>
</div>
