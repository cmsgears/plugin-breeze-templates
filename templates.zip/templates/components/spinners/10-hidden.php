<span class="spinner hidden-easy">
	<span class="cmti cmti-spinner-10 spin"></span>
</span>
